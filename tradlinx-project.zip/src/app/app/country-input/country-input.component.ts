import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-country-input',
  templateUrl: './country-input.component.html',
  styleUrls: ['./country-input.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CountryInputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
