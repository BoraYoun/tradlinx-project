export interface Port {
  locationId: number;
  cntryCd: string;
  cntryNm: string;
  cntryNmKr: string;
  portCd: string;
  portNm: string;
  portNmKr: string | null;
  label: string;
  latitude: number;
  longitude: number;
  timeZone: number;
  fclScheduleCnt: number;
}
export interface PortResponse {
  result: boolean;
  errorCode: number | string | null;
  errorMsg: string | null;
  data: Port[];
}
