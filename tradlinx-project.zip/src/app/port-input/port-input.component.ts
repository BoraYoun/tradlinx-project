import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  OnChanges,
} from '@angular/core';
import { CntryAndPortModuleService } from '../cntry-and-port-module/cntry-and-port-module.service';
import { Cntry } from '../cntry-input/cntry';
import { Port } from './port';

@Component({
  selector: 'app-port-input',
  template: ` <input
      type="text"
      placeholder="{{ placeholder }}"
      [value]="portNm"
      (input)="portNm = onChangePortInput($event)"
      (keyup.enter)="choosePort()"
      disabled="{{ disabled }}"
    />
    <ul *ngIf="showResult">
      <li *ngFor="let port of filteredPorts" (click)="choosePort(port)">
        {{ port.portNm }}
      </li>
    </ul>`,
  providers: [CntryAndPortModuleService],
  styleUrls: ['./port-input.component.scss'],
})
export class PortInputComponent implements OnChanges {
  portNm: string | null;
  placeholder: string;
  @Input() ports?: Port[];
  @Input() choosenCntry?: Cntry;
  // @Input() onChoosePort: (port: Port) => void;
  filteredPorts?: Port[];
  showResult: boolean;
  choosenPort?: Port;
  disabled?: boolean;

  constructor(private CntryAndPortModuleService: CntryAndPortModuleService) {
    this.portNm = null;
    this.placeholder = '항만 (영문)';
    this.showResult = true;
    this.choosenCntry = undefined;
    this.disabled = false;
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes['currentValue']);
    if (!changes['currentValue']) {
      // 선택된 나라(choosenCntry)가 없을 경우 입력 불가하도록
      this.disabled = true;
    }
  }

  onChangePortInput(e: Event) {
    const target = e.target as HTMLInputElement;
    const inputText = this.preprocessString(target.value);
    if (inputText.length <= 2) return target.value;

    if (inputText) {
      const filteredCountries = this.ports?.filter((country) => {
        return this.preprocessString(country.portNm).includes(inputText);
      });

      if (filteredCountries && filteredCountries.length > 0) {
        this.showResult = true;
      } else {
        this.showResult = false;
      }

      this.filteredPorts = filteredCountries;
    } else {
      this.showResult = false;
    }

    return target.value;
  }
  preprocessString(string: string) {
    const regex = /\s/gi;
    return string.replace(regex, '').toLowerCase();
  }

  choosePort(port?: Port) {
    if (port) {
      this.showResult = false;
      this.portNm = port.portNm;
      return;
    }

    if (this.filteredPorts && this.filteredPorts.length > 0) {
      this.choosenPort = this.filteredPorts[0];
      this.showResult = false;
      this.portNm = this.filteredPorts[0].portNm;
    }
  }
}
