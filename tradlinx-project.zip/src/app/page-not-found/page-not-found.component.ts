import { Component } from '@angular/core';

@Component({
  selector: 'app-cntry-input',
  template: '<h1>page not found</h1>',
  providers: [],
  styleUrls: [],
})
export class PageNotFoundComponent {
  constructor() {}
}
