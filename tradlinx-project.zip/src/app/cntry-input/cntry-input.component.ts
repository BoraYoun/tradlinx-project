import {
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  Output,
  EventEmitter,
} from '@angular/core';
import { Cntry } from './cntry';

@Component({
  selector: 'app-cntry-input',
  template: `<input
      type="text"
      placeholder="{{ placeholder }}"
      [value]="cntryNm"
      (input)="cntryNm = onChangeCntryInput($event)"
      (keyup.enter)="chooseCntry()"
    />
    <ul *ngIf="showResult">
      <li *ngFor="let country of filteredCntrys" (click)="chooseCntry(country)">
        {{ country.cntryNm }}
      </li>
    </ul> `,
  styleUrls: ['./cntry-input.component.scss'],
})
export class CntryInputComponent implements OnChanges {
  cntryNm: string | null;
  @Input() placeholder: string;
  filteredCntrys?: Cntry[];
  showResult: boolean;
  @Input() cntrys?: Cntry[];
  @Input() choosenCntry?: Cntry;
  @Output() chooseCntryEvent = new EventEmitter<Cntry>();
  constructor() {
    this.cntryNm = null;
    this.placeholder = '국가 (영문)';
    this.showResult = false;
  }
  ngOnChanges(changes: SimpleChanges): void {
    throw new Error('Method not implemented.');
  }
  onChangeCntryInput(e: Event) {
    const target = e.target as HTMLInputElement;
    const inputText = this.preprocessString(target.value);

    if (inputText) {
      const filteredCountries = this.cntrys?.filter((country) => {
        console.log(
          this.preprocessString(country.cntryNm).includes(inputText)
            ? this.preprocessString(country.cntryNm) + inputText
            : ''
        );
        return this.preprocessString(country.cntryNm).includes(inputText);
      });

      if (filteredCountries && filteredCountries.length > 0) {
        this.showResult = true;
      } else {
        this.showResult = false;
      }

      this.filteredCntrys = filteredCountries;
    } else {
      this.showResult = false;
    }

    return target.value;
  }
  preprocessString(string: string) {
    const regex = /\s/gi;
    return string.replace(regex, '').toLowerCase();
  }

  chooseCntry(country?: Cntry) {
    if (country) {
      this.chooseCntryEvent.emit(country);
      this.showResult = false;
      this.cntryNm = country.cntryNm;
      return;
    }

    if (this.filteredCntrys && this.filteredCntrys.length > 0) {
      this.chooseCntryEvent.emit(this.filteredCntrys[0]);
      this.showResult = false;
      this.cntryNm = this.filteredCntrys[0].cntryNm;
    }
  }
}
