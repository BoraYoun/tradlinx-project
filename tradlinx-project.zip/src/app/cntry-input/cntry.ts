export interface Cntry {
  cntryCd: string;
  cntryNm: string;
  cntryNmKr: string;
  cntryPart: string;
  continent: string;
}
