import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { CntryInputComponent } from './cntry-input/cntry-input.component';
import { PortInputComponent } from './port-input/port-input.component';
import { HttpErrorHandler } from './http-error-handler.service';
import { CntryAndPortModuleComponent } from './cntry-and-port-module/cntry-and-port-module.component';

@NgModule({
  declarations: [
    AppComponent,
    CntryInputComponent,
    PortInputComponent,
    CntryAndPortModuleComponent,
  ],
  imports: [BrowserModule, HttpClientModule, AppRoutingModule],
  providers: [HttpErrorHandler],
  bootstrap: [AppComponent],
})
export class AppModule {}
