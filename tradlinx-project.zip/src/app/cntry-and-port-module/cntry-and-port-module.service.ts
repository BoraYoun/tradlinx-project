import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { HttpErrorHandler, HandleError } from '../http-error-handler.service';
import { Cntry, Port, PortResponse } from './cntry-and-port-type';
import { baseApiUrl } from '../../assets/config';

@Injectable({
  providedIn: 'root',
})
export class CntryAndPortModuleService {
  cntrysUrl = baseApiUrl + '/json/cntry.json';
  portsUrl = baseApiUrl + '/port';
  private handleError: HandleError;

  constructor(private http: HttpClient, httpErrorHandler: HttpErrorHandler) {
    this.handleError = httpErrorHandler.createHandleError(
      'CntryAndPortModuleService'
    );
  }

  getCntrys(): Observable<Cntry[]> {
    return this.http
      .get<Cntry[]>(this.cntrysUrl)
      .pipe(catchError(this.handleError<Cntry[]>('getCntrys')));
  }

  getPorts(): Observable<PortResponse> {
    return this.http
      .get<PortResponse>(this.portsUrl)
      .pipe(catchError(this.handleError<PortResponse>('getPorts')));
  }
}
