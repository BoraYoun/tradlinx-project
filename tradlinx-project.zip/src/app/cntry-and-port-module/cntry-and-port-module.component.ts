import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CntryAndPortModuleService } from './cntry-and-port-module.service';
import { Cntry, Port } from './cntry-and-port-type';

@Component({
  selector: 'app-cntry-and-port-module',
  template: ` <div class="container">
    <div class="box">
      <app-cntry-input
        [cntrys]="cntrys"
        [(choosenCntry)]="choosenCntry"
        (chooseCntryEvent)="(chooseCntry)"
      ></app-cntry-input>
    </div>
    <div class="box">
      <app-port-input
        [ports]="ports"
        [choosenCntry]="choosenCntry"
        [choosenPort]="choosenPort"
        (onChoosePort)="(choosePort)"
      ></app-port-input>
    </div>
  </div>`,
  providers: [CntryAndPortModuleService],
  styleUrls: ['./cntry-and-port-module.component.scss'],
})
export class CntryAndPortModuleComponent implements OnInit {
  @Output() cntrys?: Cntry[];
  @Output() ports?: Port[];
  @Output() choosenCntry?: Cntry;
  @Output() choosenPort?: Port;

  constructor(private CntryAndPortModuleService: CntryAndPortModuleService) {}

  ngOnInit(): void {
    this.getCntrys();
    this.getPorts();
  }

  getCntrys(): void {
    this.CntryAndPortModuleService.getCntrys().subscribe(
      (cntrys) => (this.cntrys = cntrys)
    );
  }

  getPorts(): void {
    this.CntryAndPortModuleService.getPorts().subscribe(
      (wholePorts) => (this.ports = wholePorts.data)
    );
  }

  chooseCntry(country: Cntry): void {
    this.choosenCntry = country;
  }

  choosePort(port: Port): void {
    this.choosenPort = port;
  }
}
